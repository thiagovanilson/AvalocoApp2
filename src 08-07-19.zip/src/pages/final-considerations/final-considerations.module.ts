import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FinalConsiderationsPage } from './final-considerations';

@NgModule({
  declarations: [
    FinalConsiderationsPage,
  ],
  imports: [
    IonicPageModule.forChild(FinalConsiderationsPage),
  ],
})
export class FinalConsiderationsPageModule {}
