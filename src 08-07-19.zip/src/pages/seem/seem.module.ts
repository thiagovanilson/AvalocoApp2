import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SeemPage } from './seem';

@NgModule({
  declarations: [
    SeemPage,
  ],
  imports: [
    IonicPageModule.forChild(SeemPage),
  ],
})
export class SeemPageModule {}
