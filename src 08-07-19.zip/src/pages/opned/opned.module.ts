import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OpnedPage } from './opned';

@NgModule({
  declarations: [
    OpnedPage,
  ],
  imports: [
    IonicPageModule.forChild(OpnedPage),
  ],
})
export class OpnedPageModule {}
