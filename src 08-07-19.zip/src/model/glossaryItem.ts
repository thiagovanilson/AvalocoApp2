export interface GlossaryItemDTO{
    nome      : string;
    descricao : string;
    modelo : {
        codigo: number
    }
 }