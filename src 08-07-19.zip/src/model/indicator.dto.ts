export interface IndicatorDTO{
    nome  : string;
    codigo: number;
    done  : boolean;
    modelo : {
        codigo : number;
    }
 }