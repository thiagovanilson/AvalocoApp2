export interface ItemCategoryDTO{
    codigo: number;
    nome  : string;
    ordem : number;
 }