export interface ChecklistItemDTO{
   codigo    : number;
   nome      : string;
   ordem     : number;
   atendido  : number;
   observacao: string;
}