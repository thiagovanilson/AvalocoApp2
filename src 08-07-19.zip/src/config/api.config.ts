export const API_CONFIG = {
    baseUrl    : "http://avaloco.ddns.net:8080",
    themeColor : "black",
    buttonColor: "whatsapp", //secondary, dark, default, light
    bgColor    : "bgColor",
    email      : "thiago112634@gmail.com"
}